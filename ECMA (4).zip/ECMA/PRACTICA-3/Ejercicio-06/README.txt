Los documentos css y html han sido correctamente validados 
utilizando las herramientas utilizadas en la asignatura, ademas 
se ha comprobado la accesibilidad y la adaptabilidad.

Cambio de base:
Han sido introducidos las letras suficientes para operar en HEXADECIMAL,
ademas el boton DEC, alternas entre los modos DEC,HEX,OCT,BIN, los cuales
son decimal hexadecimal octal y binario. No te deja utilizar los letras
a no ser que te encuentres en modo Hexadecimal. Las operaciones continuan
funcionando con cualquier base, el modo de uso es como una calculadora normal.


TECLA DE TECLADO	TECLA DE CALCULADORA

Escape			ON/C
1			1
2			2
3			3
4			4
5			5
6			6
7			7
8			8
9			9
0			0
.			.
+			+
-			-
*			x
/			÷
Control			↑
c or C			CE
s or S			+/-
e or E			e
Enter			Enter
r or R			√
!			n!
"			x^2
'			x^y
m or M			Mod
i or I			sin
o or O			cos
a or A			tan
?			DEC/HEX/BIN/OCT
u or U			A
v or V			B
w or W			C
x or X			D
y or Y			E
z or Z			F