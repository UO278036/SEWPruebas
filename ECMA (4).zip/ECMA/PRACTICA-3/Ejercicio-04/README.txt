Los documentos css y html han sido correctamente validados 
utilizando las herramientas utilizadas en la asignatura, ademas 
se ha comprobado la accesibilidad y la adaptabilidad.

TECLA DE TECLADO	TECLA DE CALCULADORA

Escape			ON/C
1			1
2			2
3			3
4			4
5			5
6			6
7			7
8			8
9			9
0			0
. or ,			,
+			+
-			-
*			x
/			÷
=			=
Backspace		⌫
c or C			CE
Control			↑
p or P			π
!			n!
s or S			+/-
(			(
)			)
r or R			√
%			Mod
l or L			log
e or E			Exp
d or D			10^x
'			x^y
"			x^2
i or I			sin
j or J			cos
k or K			tan
m or M			MR
>			M+
<			M-
g or G			MS
b or B			MC
º			DEG/RAD
h or H			HYP
f or F			F-E