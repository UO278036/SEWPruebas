document.write("Version: " + infoNavegador.version);
document.write(" - Plataforma: " + infoNavegador.plataforma);
document.write(" - Vendedor: " + infoNavegador.vendedor);
document.write(" - Agente: " + infoNavegador.agente);
document.write(" - Esta activo Java: " + infoNavegador.javaActivo);