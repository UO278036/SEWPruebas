Los documentos css y html han sido correctamente validados 
utilizando las herramientas utilizadas en la asignatura, ademas 
se ha comprobado la accesibilidad y la adaptabilidad.

TECLA DE TECLADO	TECLA DE CALCULADORA

Escape			ON/C
1			1
2			2
3			3
4			4
5			5
6			6
7			7
8			8
9			9
0			0
.			.
+			+
-			-
*			x
/			÷
Control			↑
c or C			CE
s or S			+/-
e or E			e
Enter			Enter
r or R			√
!			n!
"			x^2
'			x^y
m or M			Mod
i or I			sin
o or O			cos
a or A			tan