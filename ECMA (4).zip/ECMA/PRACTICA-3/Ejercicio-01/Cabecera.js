var asignatura = new Object();

asignatura.nombre = "SEW";
asignatura.titulacion = "Grado en Ingeneria informatica del software";
asignatura.centro = "Escuela de Ingenieria Informatica de Oviedo";
asignatura.universidad = "Universidad de Oviedo";
asignatura.cursoActual = "2022-2023";
asignatura.estudianteNombre = "Raúl Fernández España";
asignatura.estudianteEmail = "uo278036@uniovi.es";