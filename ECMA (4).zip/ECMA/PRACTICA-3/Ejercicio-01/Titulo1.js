/*
    Escribe en objeto el nombre de la asignatura 
    en un encabezado h1
*/
document.write("<h1>");
document.write(asignatura.nombre);
document.write("</h1>");