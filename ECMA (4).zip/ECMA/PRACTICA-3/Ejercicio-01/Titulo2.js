/*
    Escribe en objeto la titulacion 
    en un encabezado h2
*/
document.write("<h2>");
document.write(asignatura.titulacion);
document.write("</h2>");