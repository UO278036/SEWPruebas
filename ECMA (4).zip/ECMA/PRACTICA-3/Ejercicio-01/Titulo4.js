/*
    Escribe en objeto la ASIGNATURA 
    en un encabezado h4
*/
document.write("<h4>");
document.write(asignatura.universidad);
document.write("</h4>");