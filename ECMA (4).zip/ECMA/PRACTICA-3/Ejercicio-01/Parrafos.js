document.write("<section>");
document.write("<h5> Datos del estudiante </h5>");
document.write("<p> Curso actual: " + asignatura.cursoActual + " </p>");
document.write("<p> Nombre del estudiante: " + asignatura.estudianteNombre + " </p>");
document.write("<p> E-mail del estudiante: " + asignatura.estudianteEmail + " </p>");
document.write("</section>");