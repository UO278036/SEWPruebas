<script>
       //Versión 1.0 01/03/2011 Juan Manuel Cueva Lovelle. Universidad de Oviedo
       //Versión 1.1 23/10/2021 
	   //Versión 1.2 07/11/2021
      $(document).ready(function(){
        $("button").click(function(){
          $("p").hide();
        })
      })
  </script>